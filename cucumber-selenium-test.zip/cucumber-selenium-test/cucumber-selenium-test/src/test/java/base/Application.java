package base;

public enum Application
{
    app;

}
