package base;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;



public class Setup {

	protected static HashMap<Long, WebDriver> driverMap;
	public static long id = Thread.currentThread().getId();
	DateFormat dateFormat;
	public Date date;
	public static String dateName = new SimpleDateFormat("yyyymmddhhmmss").format(new Date());
	public static String ScrenshotPath = "";
	public static ExtentReports extent;
	public static ExtentTest test;
	public static String downloadFilepath;
	public static JavascriptExecutor jse;


	@BeforeTest
	public void startReport(){
		extent = new ExtentReports ("./src/test/resources/"+dateName+"ExtentReport.html",true);
		extent.loadConfig(new File("./src/test/resources/extent-config.xml"));
	}


	public static WebDriver getDriverInstance()
	{

		return driverMap.get(id);
	}

	@AfterMethod
	public void getResult(ITestResult result,Method m) throws IOException{
		if(result.getStatus() == ITestResult.FAILURE){
			test.log(LogStatus.FAIL, "Test Case Failed is "+result.getName());
			test.log(LogStatus.FAIL, "Test Case Failed is "+result.getThrowable());
		}else if(result.getStatus() == ITestResult.SKIP){
			test.log(LogStatus.SKIP, "Test Case Skipped is "+result.getName());
		}
		extent.endTest(test);
		extent.flush();
	}


	@AfterTest
	public void destroy() throws IOException
	{

		driverMap = null;
	}

}
