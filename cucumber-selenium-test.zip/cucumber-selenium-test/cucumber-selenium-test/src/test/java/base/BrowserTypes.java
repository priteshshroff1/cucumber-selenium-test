package base;

public enum  BrowserTypes
{
    FIREFOX, CHROME, IE, BrowserStack;
}
