package base;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.Method;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;
import org.apache.commons.io.FileUtils;
import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Platform;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import com.google.common.base.Function;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import utility.ConfigProperties;
import utility.Utils;

public class TestBase {

	protected static HashMap<Long, WebDriver> driverMap;
	private WebDriver webDriver;
	public static long id = Thread.currentThread().getId();
	static String browser;
	DateFormat dateFormat;
	protected static String sFinalResult = "PASSED!";
	public static ConfigProperties configProperties;
	private String resourcePath = "src\\test\\resources\\";
	public static String ConfigPath = null;
	public Date date;
	public static String dateName = new SimpleDateFormat("yyyymmddhhmmss").format(new Date());
	public static String ScrenshotPath = "";
	public static ExtentReports extent;
	public static ExtentTest test;
	public static String downloadFilepath;
	public static JavascriptExecutor jse;
	public static FirefoxProfile profile;
	public static final String AUTOMATE_USERNAME = "priteshshroff1";
	public static final String AUTOMATE_ACCESS_KEY = "5xSNm6NYqyo4BV5mFvoJ";
	public static final String URL = "https://" + AUTOMATE_USERNAME + ":" + AUTOMATE_ACCESS_KEY + "@hub-cloud.browserstack.com/wd/hub";
    public void createWebdriver() 
    {
	
		configProperties = new ConfigProperties();
		ConfigPath = resourcePath + configProperties.configPath;
		DOMConfigurator.configure("./SetupFiles/log4j.xml");
		dateFormat = new SimpleDateFormat("M/d/yyyy");
		date = new Date();
		System.out.println(dateFormat.format(date));

	

	
		extent = new ExtentReports (System.getProperty("user.dir") +"/test-output/ExtentReports/"+dateName+"ExtentReport.html",true);
		extent.loadConfig(new File("./extent-config.xml"));
	
	
	

		if (webDriver == null)
		{
			try
			{
				switch (BrowserTypes.valueOf(configProperties.browser))
				{
				case CHROME:
					System.setProperty("webdriver.chrome.driver", "./SetupFiles/chromedriver.exe");
					ChromeOptions options = new ChromeOptions();
					options.addArguments("chrome.switches", "--disable-extensions");
					DesiredCapabilities capabilitiesChrome = DesiredCapabilities.chrome();
				
					HashMap<String, Object> chromePrefs = new HashMap<String, Object>();
					chromePrefs.put("safebrowsing.enabled", "false"); options.setExperimentalOption("prefs", chromePrefs);
					capabilitiesChrome.setPlatform(Platform.WINDOWS);
					if (configProperties.isRemote().equalsIgnoreCase("true"))
					{
						capabilitiesChrome.setBrowserName("chrome");
						webDriver = new RemoteWebDriver(new URL(configProperties.getNodeUrl()), capabilitiesChrome);
						System.out.println("Launching grid for Chrome browser.");
					}
					else
					{
						chromePrefs.put("download.default_directory", downloadFilepath);
						chromePrefs.put("credentials_enable_service", false);
						chromePrefs.put("profile.password_manager_enabled", false);
						chromePrefs.put("download.prompt_for_download", false);
						options.setExperimentalOption("prefs", chromePrefs);
						capabilitiesChrome.setCapability(ChromeOptions.CAPABILITY, options);
						webDriver = new ChromeDriver(capabilitiesChrome);
						System.out.println("Going to launch Chrome driver!");
					}

					Reporter.log("Going to launch Chrome driver!");
					break;

				case FIREFOX:
					System.setProperty("webdriver.gecko.driver", ".\\SetupFiles\\geckodriver.exe");
					DesiredCapabilities capabilities = DesiredCapabilities.firefox();
					capabilities.setCapability("marionette", true);
					webDriver = new FirefoxDriver(capabilities);
					System.out.println("Going to launch Firefox driver!");
					break;

				case IE:
					System.setProperty("webdriver.ie.driver", ".\\SetupFiles\\IEDriverServer.exe");
					DesiredCapabilities capabilitiesIE = DesiredCapabilities.internetExplorer();
					capabilitiesIE.setPlatform(org.openqa.selenium.Platform.WINDOWS);
					if (configProperties.isRemote().equalsIgnoreCase("true"))
					{
						System.out.println("Inside remote::" + configProperties.getNodeUrl());
						capabilitiesIE.setPlatform(Platform.WINDOWS);
						capabilitiesIE.setCapability(CapabilityType.BROWSER_NAME, "internet explorer");
						capabilitiesIE.setCapability(CapabilityType.VERSION, "11");
						capabilitiesIE.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
						capabilitiesIE.setJavascriptEnabled(true);
						capabilitiesIE.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING, true);
						webDriver = new RemoteWebDriver(new URL(configProperties.getNodeUrl()), capabilitiesIE);
						System.out.println("Launching grid for IE browser.");
					}
					else
					{
						capabilitiesIE.setCapability(
								InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
						webDriver = new InternetExplorerDriver(capabilitiesIE);
						System.out.println("Going to launch IE driver!");
					}
					Reporter.log("Going to launch IE driver!");
					break;

				case BrowserStack:

					DesiredCapabilities caps = new DesiredCapabilities();
					caps.setCapability("os", configProperties.BrowsertStackOS);
					caps.setCapability("os_version", configProperties.BrowsertStackOSVersion);
					caps.setCapability("browser", configProperties.browserforBrowsertStack);
					caps.setCapability("browser_version", configProperties.BrowserStackbrowserVersion);
					caps.setCapability("browserstack.local", true);
					caps.setCapability("resolution", "1366x768");



					if(configProperties.browserforBrowsertStack.equals("Chrome"))
					{
						caps.setCapability("browser.download.folderList", 2);
						caps.setCapability("browser.download.manager.showWhenStarting", false);
						//caps.setCapability("browser.helperApps.neverAsk.saveToDisk", "application/msword, application/csv, application/ris, text/csv, image/png, application/pdf, text/html, text/plain, application/zip, application/x-zip, application/x-zip-compressed, application/download, application/octet-stream");
						caps.setCapability("browser.download.manager.focusWhenStarting", false);
						caps.setCapability("browser.download.manager.alertOnEXEOpen", false);
						//caps.setCapability("browser.download.dir", downloadFilepath);
						caps.setCapability("browser.download.manager.showAlertOnComplete", false);
						caps.setCapability("browser.helperApps.neverAsk.saveToDisk", "application/octet-stream");
						caps.setCapability("project", "Early proof Automation");

					}else {

						profile = new FirefoxProfile();
						profile.setPreference("browser.download.folderList", 2);
						profile.setPreference("browser.download.manager.showWhenStarting", false);
						profile.setPreference("browser.download.manager.focusWhenStarting", false);
						profile.setPreference("browser.download.useDownloadDir", true);
						profile.setPreference("browser.helperApps.alwaysAsk.force", false);
						profile.setPreference("browser.download.manager.alertOnEXEOpen", false);
						profile.setPreference("browser.download.manager.closeWhenDone", true);
						profile.setPreference("browser.download.manager.showAlertOnComplete", false);
						profile.setPreference("browser.download.manager.useWindow", false);

					
						profile.setPreference("browser.download.manager.alertOnEXEOpen", false);
						profile.setPreference("browser.helperApps.neverAsk.saveToDisk", "application/msword, application/csv, application/ris, text/csv, image/png, application/pdf, text/html, text/plain, application/zip, application/x-zip, application/x-zip-compressed, application/download, application/octet-stream");
						profile.setPreference("services.sync.prefs.sync.browser.download.manager.showWhenStarting", false);
						profile.setPreference("pdfjs.disabled", true);

						caps.setCapability(FirefoxDriver.PROFILE, profile);
					}

					webDriver = new RemoteWebDriver(new URL(URL), caps);
					jse = (JavascriptExecutor) webDriver;

					//((RemoteWebDriver) webDriver).setFileDetector(new LocalFileDetector());

					break;



				default:
					new RuntimeException("Unsupported browser type");
				}
				Thread.sleep(100);
				//webDriver.manage().window().maximize();
				webDriver.manage().timeouts().implicitlyWait(TimeConstants.implicitWaitTime, TimeUnit.SECONDS);
				driverMap = new HashMap<Long, WebDriver>();
				driverMap.put(id, webDriver);
			}
			catch (Exception e)
			{
				System.out.println("Unable to acquire the webdriver ." + e);
				try {
					throw e;
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		}
    }
    


    
	public static WebDriver getDriverInstance()
	{
        if (driverMap == null)
        {
        	TestBase obj1= new TestBase();
        	obj1.createWebdriver();
        }	
		return driverMap.get(id);
	}


	/**
	 * Explicit wait.
	 */
	public static void waitForPageLoad()
	{
		WebDriverWait wait = new WebDriverWait(getDriverInstance(), TimeConstants.pageLoadTime);
		wait.until(new Function<WebDriver, Boolean>()
		{
			@Override
			public Boolean apply(WebDriver driver)
			{
				return String.valueOf(((JavascriptExecutor) driver).executeScript("return document.readyState"))
						.equals("complete");
			}
		});
	}

	public static String getScreenShot(WebDriver driver, String screenshotName) throws IOException {
		TakesScreenshot ts = (TakesScreenshot) driver;
		File source = ts.getScreenshotAs(OutputType.FILE);
		dateName = new SimpleDateFormat("yyyymmddhhmmss").format(new Date());
		String destination = ScrenshotPath+screenshotName+dateName+".png";
		File finalDestination = new File(destination);
		FileUtils.copyFile(source, finalDestination);
		return destination;
	}


}
