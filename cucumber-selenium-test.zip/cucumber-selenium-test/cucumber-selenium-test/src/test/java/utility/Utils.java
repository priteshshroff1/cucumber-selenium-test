package utility;

import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import java.awt.HeadlessException;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardWatchEventKinds;
import java.nio.file.WatchEvent;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
/*import org.apache.commons.mail.DefaultAuthenticator;
import org.apache.commons.mail.Email;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.SimpleEmail;*/
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.custommonkey.xmlunit.DetailedDiff;
import org.custommonkey.xmlunit.Diff;
import org.custommonkey.xmlunit.Difference;
import org.custommonkey.xmlunit.XMLUnit;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.springframework.web.util.UriUtils;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import com.google.common.io.Files;
import base.TestBase;
import io.restassured.RestAssured;
import io.restassured.response.Response;


public class Utils extends TestBase {

	static public String NavigatetoLink(String sURLLink)
	{

		String sTotalTime=null;

		try
		{
			TestBase.getDriverInstance().manage().deleteAllCookies();
			long start = System.currentTimeMillis();

			TestBase.getDriverInstance().get(sURLLink);
			//TestBase.waitForPageLoad();
			long finish = System.currentTimeMillis();
			double totalTime = (finish - start);
			double loadtime = (totalTime / 1000);
			sTotalTime = Double.toString(loadtime);
			System.out.println("Total Time for page load : " + sTotalTime + " sec");
			//TestBase.getDriverInstance().close();
			// return sTotalTime;

		}
		catch (AssertionError e)
		{
			// Log.warn("ERROR: Cannot navigate to link");
			e.printStackTrace();
		}
		//return sTotalTime;
		return sTotalTime;

	}

	public static void waitFor(int seconds) {
		try {
			Thread.sleep(seconds * 1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	//select the dropdown using "select by visible text"
	public static void dropDownSelectByText(WebElement webElement, String VisibleText){
		Select selObj=new Select(webElement);
		selObj.selectByVisibleText(VisibleText);
	}

	//select the dropdown using "select by index"
	public static void dropDownSelectByIndex(WebElement webElement, int IndexValue){
		Select selObj=new Select(webElement);
		selObj.selectByIndex(IndexValue);
	}

	//select the dropdown using "select by value"
	public static void dropDownSelectByValue(WebElement webElement, String Value){
		Select selObj=new Select(webElement);
		selObj.selectByValue(Value);
	}

	static public String calculateProcessingTime(long start, long finish)
	{

		String sTotalTime=null;

		double totalTime = (finish - start);
		double loadtime = (totalTime / 1000);
		sTotalTime = Double.toString(loadtime);
		return sTotalTime;
	}

	public static Set<String> switchToWindow(String titleOfWindow) 

	{
		Set<String> allWindowhandles =  getDriverInstance().getWindowHandles();

		if(titleOfWindow.equals(""))
		{

			if (allWindowhandles.size()>2)
			{
				return allWindowhandles;
			}	
			else if(allWindowhandles.size()==1)
			{
				for (String handler:allWindowhandles)
					getDriverInstance().switchTo().window(handler);

			}	
			else {	

				String parentWindowHandler= getDriverInstance().getWindowHandle();
				for (String handler:allWindowhandles)
				{
					if (!(handler.equals(parentWindowHandler)))
					{
						getDriverInstance().switchTo().window(handler);
					}

				}
			}
		}

		else {


			for (String handler:allWindowhandles)
			{
				if((getDriverInstance().switchTo().window(handler).getTitle()).equals(titleOfWindow))
				{
					getDriverInstance().manage().window().maximize();
					break;
				}
			}

		}
		return allWindowhandles;

	}


	public static void clickOnWebElement(WebElement ele)
	{

		ele.click();

	}


	public static void switchToFrame(String frameName)
	{
		getDriverInstance().switchTo().frame(frameName);
	}


	public static void clickOnWebElement(WebElement ele, String FrameName )
	{

		switchToFrame(FrameName);
		ele.click();

	}


	public static void sendText(WebElement ele, String value)
	{
		ele.sendKeys(value);
	}

	public static void selectCheckBox(WebElement element)
	{
		if (!(element.isSelected()))
		{
			clickOnWebElement(element);
		}
	}


}

