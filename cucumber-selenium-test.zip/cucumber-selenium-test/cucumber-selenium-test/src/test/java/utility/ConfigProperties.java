package utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class ConfigProperties
{

	public String userName;
	public String password;
	public String channel;
	public String isRemote;
	public String configPath;
	public String nodeUrl;
	private String environment;
	private String application;
	public  String browser;
	public String browserforBrowsertStack;
	public String BrowsertStackOS;
	public String BrowsertStackOSVersion;
	public String BrowserStackbrowserVersion;
    public String pathOfExcel;
	

	public String getUserName()
	{
		return userName;
	}

	public String getPassword()
	{
		return password;
	}
	
	public String getPathOfExcel()
	{
		return pathOfExcel;
	}

	public String getConfigPath()
	{
		return configPath;
	}

	public String getEnvironment()
	{
		return environment;
	}

	public String getApplication()
	{
		return application;
	}

	public String isRemote()
	{
		return isRemote;
	}
	
	public String getNodeUrl()
	{
		return nodeUrl;
	}

	public String getChannel()
	{
		return channel;
	}


	public ConfigProperties()
	{	File file = new File("./SetupFiles/configure.properties");
		
		FileInputStream fileInput = null;
		try
		{
			fileInput = new FileInputStream(file);
		}
		catch (FileNotFoundException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Properties prop = new Properties();
		try
		{
			prop.load(fileInput);
		}
		catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		isRemote= prop.getProperty("isRemote");
		browser = prop.getProperty("browser");
		browserforBrowsertStack = prop.getProperty("browserforBrowsertStack");
		BrowsertStackOS = prop.getProperty("BrowsertStackOS");
		BrowsertStackOSVersion = prop.getProperty("BrowsertStackOSVersion");
		BrowserStackbrowserVersion = prop.getProperty("BrowserStackbrowserVersion");
		environment = prop.getProperty("environment");
		application = prop.getProperty("application");
		channel = prop.getProperty("channel");
		userName = prop.getProperty("userName");
		password = prop.getProperty("password");
		pathOfExcel=prop.getProperty("pathOfExcel");

		System.setProperty("browser", browser);
		System.setProperty("browserforBrowsertStack", browserforBrowsertStack);
		System.setProperty("BrowsertStackOS", BrowsertStackOS);
		System.setProperty("BrowsertStackOSVersion", BrowsertStackOSVersion);
		System.setProperty("BrowserStackbrowserVersion", BrowserStackbrowserVersion);
		System.setProperty("environment", environment);
		System.setProperty("application", application);
		System.setProperty("channel", channel);
		System.setProperty("userName", userName);
		System.setProperty("password", password);
		
	}
}


