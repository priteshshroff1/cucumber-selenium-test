package com.page.searchFunctionality;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import Page.BasePage;

public class jpmorganHomePage extends BasePage {

	@FindBy(xpath="//img[@class='first-logo' and @alt='J.P. Morgan logo']")
	WebElement jpmorganLogo;
	
	public WebElement getjpmorganLogo(){
		return jpmorganLogo;
	}
	
	@Override
	public void verifyPage() {
		// TODO Auto-generated method stub
		
	}

}
