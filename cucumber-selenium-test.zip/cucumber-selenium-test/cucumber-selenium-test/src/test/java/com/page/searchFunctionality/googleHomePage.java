package com.page.searchFunctionality;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import Page.BasePage;

public class googleHomePage extends BasePage{

	@FindBy(xpath="//img[@class='lnXdpd' and @alt='Google']")
	WebElement googleLogo;
	
	@FindBy(xpath="//input[@title='Search']")
	WebElement googleSearchTextBox;

	//@FindBy(xpath="//input[@value='Google Search' and @data-ved='0ahUKEwjWsNPE46PzAhWeIbkGHXe7CrAQ4dUDCAs']")
	@FindBy(xpath="//div[@class='FPdoLc lJ9FBc']/center/input[1]")
	WebElement googleSearchButton;
	
	@FindBy(xpath="//*[@id=\"rso\"]")
	WebElement searchResult;
	
	@FindBy(tagName="a")
	List<WebElement> allLinks;
	
	public WebElement getgoogleLogo(){
		return googleLogo;
	}
	
	public WebElement getgooglesearchtextbox(){
		return googleSearchTextBox;
	}
	
	public WebElement getgooglesearchbutton(){
		return googleSearchButton;
	}
	
	public WebElement getsearchresult(){
		return searchResult;
	}
	
	
	
	
	@Override
	public void verifyPage() {
		// TODO Auto-generated method stub
		
	}

}
