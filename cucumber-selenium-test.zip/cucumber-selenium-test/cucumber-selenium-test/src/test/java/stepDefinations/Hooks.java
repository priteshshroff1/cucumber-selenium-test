package stepDefinations;

import base.TestBase;
import io.cucumber.java.After;
import io.cucumber.java.Before;

public class Hooks extends TestBase {
    @Before
	public void beforeValidation()
	{
    	TestBase.getDriverInstance();
	}
    
    @After
    public void afterValidation()
    {
    	TestBase.getDriverInstance().close();
    }
}
