package stepDefinations;


	import static org.testng.Assert.assertTrue;

	import java.io.IOException;
	import java.util.List;

	import org.openqa.selenium.By;
	import org.openqa.selenium.WebElement;
	import org.testng.Assert;
	import org.testng.annotations.BeforeClass;
	import org.testng.annotations.Test;

import com.page.searchFunctionality.googleHomePage;
import com.page.searchFunctionality.jpmorganHomePage;

import base.TestBase;
	import io.cucumber.java.en.And;
	import io.cucumber.java.en.Given;
	import io.cucumber.java.en.Then;
	import io.cucumber.java.en.When;
	import utility.Utils;





public class stepDefinationSearchFunctionality {
		
			// TODO Auto-generated constructor stub


		googleHomePage googlehomepage=new googleHomePage();
		jpmorganHomePage jpmorganhomepage= new jpmorganHomePage();
		
		
		@Given("^User is on google homepage$")
	    public void user_is_on_google_homepage() throws Throwable {
			//stepDefination step= new stepDefination();
			
			Utils.NavigatetoLink("http://www.google.com");
			//googlehomepage = new googleHomePage();
			Assert.assertEquals("Google", googlehomepage.getgoogleLogo().getAttribute("alt"),"User is not on Google HomePage");
			System.out.println("User is landed on Google HomePage");
	    }

		@When("^User search for (.+)$")
		public void user_search_for(String searchKeyword ) throws Throwable {
	        googlehomepage.getgooglesearchtextbox().sendKeys(searchKeyword);
	        googlehomepage.getgoogleLogo().click();
	        Utils.waitFor(3);
	        if( googlehomepage.getgooglesearchbutton().isEnabled())
	        googlehomepage.getgooglesearchbutton().click();
			//System.out.println(searchKeyword);
	        
	    }

		@Then("^User click on the first result returned in google search$")
	    public void user_click_on_the_first_result_returned_in_google_search() throws Throwable {
	       
			//List<WebElement> allLinks = TestBase.getDriverInstance().findElements(By.tagName("a"));
			 List<WebElement> allSearchLinks = (googlehomepage.getsearchresult()).findElements(By.tagName("a"));
			
			 allSearchLinks.get(0).click();
	    }
	   
		@And("^the (.+) logo is displayed$")
	    public void the_something_logo_is_displayed(String strArg1) throws Throwable {
			boolean logoPresent = jpmorganhomepage.getjpmorganLogo().isDisplayed();
			assertTrue(logoPresent,strArg1 + "logo is not Present");
			System.out.println(strArg1 + "logo is present");
	    }
	}


